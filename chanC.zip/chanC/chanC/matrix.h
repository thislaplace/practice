#ifndef _MATRIX_H
#define _MATRIX_H


#define IN 
#define OUT 

#define TRUE    (0)
#define FALSE   (1)

typedef int BOOL; 

typedef struct tagMatrix 
{  
	unsigned int ucRow;  //行
	unsigned int ucCol;  //列
	float *pfDataAdd; 
}Matrix_s;

BOOL CreatMatrix(IN unsigned int ucRow, 
				IN unsigned int ucCol, 
		  		IN float **pvData, 
			 	OUT Matrix_s *pstMatrix);
BOOL DestoryMatrix(IN Matrix_s *pstMatrix);
unsigned int GetMatrixRow(const Matrix_s *pstMatrixA);
unsigned int GetMatrixCol(const Matrix_s *pstMatrixA);
BOOL AddMatrix(IN const Matrix_s *pstMatrixA,
				  IN const Matrix_s *pstMatrixB,
				  OUT Matrix_s *pstMatrixResult);
BOOL SubtractMatrix(IN const Matrix_s *pstMatrixA,
					    IN const Matrix_s *pstMatrixB,
						OUT Matrix_s *pstMatrixResult);


#endif

