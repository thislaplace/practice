#ifndef _MATRIX_H
#define _MATRIX_H

#define TRUE    (0)
#define FALSE   (1)

typedef int bool; 

typedef struct tagMatrix 
{  
	unsigned int ucRow;  //行
	unsigned int ucCol;  //列
	unsigned short usRev;  
	float *pfDataAdd; 
}Matrix_s;

unsigned int GetMatrixRow(const Matrix_s *pstMatrixA);
unsigned int GetMatrixCol(const Matrix_s *pstMatrixA);


/*
int InputRowColInfo(unsigned char *pucRow, unsigned char *pucCol);
int CreateMatrixMem(void *pvData);
int InputMatrixData(void *pvData);
int PrintMatrixData(void *pvData);
int PrintInverseMatrixData(void *pvData);
int Show_matrix(Matrix_s *pstMatrixA, Matrix_s *pstMatrixB);
*/

#endif