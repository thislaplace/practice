#include"matrix.h"


unsigned int GetMatrixRow(IN const Matrix_s *pstMatrixA)
{
	return pstMatrixA->ucRow;
}

unsigned int GetMatrixCol(IN const Matrix_s *pstMatrixA)
{
	return pstMatrixA->ucCol;
}

BOOL CreatMatrix(IN unsigned char ucRow, 
				IN unsigned char ucCol, 
		  		IN const float *pvData, 
			 	OUT Matrix_s *pstMatrix)
{
	
	
; 
}






BOOL AddMatrix( const Matrix_s *pstMatrixA,
			    const Matrix_s *pstMatrixB,
			    Matrix_s *pstMatrixC)
{
	if((pstMatrixA->ucRow != pstMatrixB->ucRow)||(pstMatrixA->ucCol != pstMatrixB->ucCol))
		return FALSE;

	

}



