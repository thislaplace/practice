#include"matrix.h"


unsigned int GetMatrixRow(IN const Matrix_s *pstMatrixA)
{
	return pstMatrixA->ucRow;
}

unsigned int GetMatrixCol(IN const Matrix_s *pstMatrixA)
{
	return pstMatrixA->ucCol;
}

BOOL CreatMatrix(IN unsigned char ucRow, 
				IN unsigned char ucCol, 
		  		IN const float *pvData, 
			 	OUT Matrix_s *pstMatrix)
{
	int i;
	int j;
	if (pvData == NULL)
	{
		printf("Creat matrix fault; para is null.\r\n");
		return FALSE;
	}
	else
	{
		Matrix_s *pstTmpData = NULL;
		pstTmpData->ucRow = ucRow;
		pstTmpData->ucCol = ucCol;
		for(i = 0;i < pstTmpData->ucRow;i++)
		{
			for(i = 0;i < pstTmpData->ucCol;i++)
			{
				;
			}
		}
		return TRUE;
	}

	


	





		if (pvData == NULL)
		{
			printf("para is null.\r\n");
			return EX_FALSE;
		}
		else
		{
			pstTmpData = (Matrix_s *)pvData;
		}
	
		/* create result matrix C */
		memset(pstTmpData, 0, sizeof(Matrix_s));
	
		pstTmpData->ucRow = ucRow;
		pstTmpData->ucCol = ucCol;
	
		iRet = CreateMatrixMem(pstTmpData);
		if (iRet != EX_TRUE)
		{
			printf("err create result Matrix C!\r\n");
			return iRet;
		}
	
		return EX_TRUE;

}






BOOL AddMatrix( const Matrix_s *pstMatrixA,
			    const Matrix_s *pstMatrixB,
			    Matrix_s *pstMatrixC)
{
	if((pstMatrixA->ucRow != pstMatrixB->ucRow)||(pstMatrixA->ucCol != pstMatrixB->ucCol))
		return FALSE;

	

}



