#include <stdio.h>
#include <stdlib.h>
#include"matrix.h"

void DisplayMatrix(IN const Matrix_s *pstMatrix)
{
	int i = 0;
	int j = 0;
	printf("The matrix is:\r\n");
	for(i = 0;i < pstMatrix->ucRow;i++)
	{
		for(j = 0;j < pstMatrix->ucCol;j++)
		{
			printf(" %8.2f",*(pstMatrix->pfDataAdd + i * pstMatrix->ucCol + j));
		}
		printf("\r\n");
		
	}
}

unsigned int GetMatrixRow(IN const Matrix_s *pstMatrix)
{
	return pstMatrix->ucRow;
}

unsigned int GetMatrixCol(IN const Matrix_s *pstMatrix)
{
	return pstMatrix->ucCol;
}

BOOL CreatMatrix(IN unsigned int ucRow, 
				IN unsigned int ucCol, 
		  		IN const float *pvData, 
			 	OUT Matrix_s *pstMatrix)
{
	int i = 0;
	int j = 0;
	if (pvData == NULL)
	{
		printf("Creat matrix fault; para is null.\r\n");
		return FALSE;
	}
	else
	{	
		memset(pstMatrix, 0, sizeof(Matrix_s));
		pstMatrix->ucRow = ucRow;
		pstMatrix->ucCol = ucCol;
		pstMatrix->pfDataAdd = (float*)malloc(sizeof(float)*pstMatrix->ucRow*pstMatrix->ucCol);
		if(pstMatrix->pfDataAdd == NULL)
		{
			return FALSE;
		}
		else
		{
			for(i = 0;i < pstMatrix->ucRow;)
			{
				for(j = 0;j < pstMatrix->ucCol;)
				{
					*(pstMatrix->pfDataAdd + i * pstMatrix->ucCol + j) = *(pvData + i * pstMatrix->ucCol + j);
					j++

				}
				i++
			}		
			return TRUE;
		}
	}
}

BOOL DestoryMatrix(IN Matrix_s *pstMatrix)
{
;
}




BOOL AddMatrix( const Matrix_s *pstMatrixA,
			    const Matrix_s *pstMatrixB,
			    Matrix_s *pstMatrixC)
{
	if((pstMatrixA->ucRow != pstMatrixB->ucRow)||(pstMatrixA->ucCol != pstMatrixB->ucCol))
		return FALSE;

	

}



