#include <stdio.h>
#include"./matrix.h"


int main(int argc, char *argv[])
{
	float s[6][3]={{300,100,150},{400,150,100},{300,500,200},{350,200,100},{-100,-100,-100},{-100,-100,-100}};
	
	
	
	printf("Hello C-Free!\n");
	return 0;
}

