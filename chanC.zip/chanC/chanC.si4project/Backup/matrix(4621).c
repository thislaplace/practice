#include"matrix.h"


unsigned int GetMatrixRow(IN const Matrix_s *pstMatrixA)
{
	return pstMatrixA.ucRow;
}

unsigned int GetMatrixCol(IN const Matrix_s *pstMatrixA)
{
	return pstMatrixA.ucCol;
}

bool AddMatrix(IN const Matrix_s *pstMatrixA,
			   IN const Matrix_s *pstMatrixB,
			   OUT Matrix_s *pstMatrixC)
{
	if((pstMatrixA.ucRow != pstMatrixB.ucRow)||(pstMatrixA.ucCol != pstMatrixB.ucCol))
		return FALSE;

	

}



