#include <stdio.h>
#include"./matrix.h"

#define TEST_ROW (3)
#define TEST_COL (6)

int main(int argc, char *argv[])
{
	float TEST_data1[TEST_ROW*TEST_COL]={300.0,100.1,150.2,400.3,150.4,100.5,
						 				300.0,500.1,200.2,350.3,200.4,100.5,
 										100.0,100.1,100.2,100.3,100.4,100.5};
	float TEST_data2[TEST_ROW*TEST_COL]={300.0,100.1,150.2,400.3,150.4,100.5,
						 				300.0,500.1,200.2,350.3,200.4,100.5,
 										100.0,100.1,100.2,100.3,100.4,100.5};
	Matrix_s *pstMatrix_data;
	pstMatrix_data = (Matrix_s*) malloc(sizeof(Matrix_s));
	if (pstMatrix_data == NULL)
	{
		printf("Malloc fault; para is null.\r\n");
		return FALSE;
	}
	
	if(FALSE != CreatMatrix(TEST_ROW, TEST_COL, TEST_data1, pstMatrix_data))
	{
		DisplayMatrix(pstMatrix_data);
	}

	DestoryMatrix(pstMatrix_data);

	return 0;
}

