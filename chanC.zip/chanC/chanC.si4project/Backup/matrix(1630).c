#include <stdio.h>
#include <stdlib.h>
#include"./matrix.h"

void DisplayMatrix(IN const Matrix_s *pstMatrix)
{
	int i = 0;
	int j = 0;
	printf("The matrix is:\r\n");
	for(i = 0;i < pstMatrix->ucRow;i++)
	{
		for(j = 0;j < pstMatrix->ucCol;j++)
		{
			printf(" %8.2f",*(pstMatrix->pfDataAdd + i * pstMatrix->ucCol + j));
		}
		printf("\r\n");		
	}
}

BOOL CreatMatrix(IN unsigned int ucRow, 
					IN unsigned int ucCol, 
		  			IN const float *pvData, 
			 		OUT Matrix_s *pstMatrix)
{
	int i = 0;
	int j = 0;
	if (pvData == NULL)
	{
		printf("Creat matrix fault: Data is null.\r\n");
		return FALSE;
	}
	else
	{	
		memset(pstMatrix, 0, sizeof(Matrix_s));
		pstMatrix->ucRow = ucRow;
		pstMatrix->ucCol = ucCol;
		pstMatrix->pfDataAdd = (float*)malloc(sizeof(float)*pstMatrix->ucRow*pstMatrix->ucCol);
		if(pstMatrix->pfDataAdd == NULL)
		{
			printf("Malloc fault.\r\n");
			return FALSE;
		}
		else
		{
			for(i = 0;i < pstMatrix->ucRow;i++)
			{
				for(j = 0;j < pstMatrix->ucCol;j++)
				{
					*(pstMatrix->pfDataAdd + i * pstMatrix->ucCol + j) = *(pvData + i * pstMatrix->ucCol + j);
				}				
			}	
			return TRUE;
		}
	}
}

BOOL DestoryMatrix(IN Matrix_s *pstMatrix)
{
	free(pstMatrix->pfDataAdd);
	pstMatrix->pfDataAdd = NULL;
	free(pstMatrix);
	pstMatrix = NULL;
}

unsigned int GetMatrixRow(IN const Matrix_s *pstMatrix)
{
	return pstMatrix->ucRow;
}
					
unsigned int GetMatrixCol(IN const Matrix_s *pstMatrix)
{
	return pstMatrix->ucCol;
}

BOOL AddMatrix(IN const Matrix_s *pstMatrixA,
			      IN const Matrix_s *pstMatrixB,
			      OUT Matrix_s *pstMatrixResult)
{
	int i;
	int j;
	if((pstMatrixA->ucRow != pstMatrixB->ucRow)||(pstMatrixA->ucCol != pstMatrixB->ucCol))
	{
		printf("相加的两个矩阵的行或列不满足矩阵相加条件！\r\n");
		return FALSE;
	}
	else if((pstMatrixA->ucRow != pstMatrixResult->ucRow)||(pstMatrixA->ucCol != pstMatrixResult->ucCol))
	{
		printf("矩阵相加的结果矩阵的行或列不满足矩阵相加条件！\r\n");
		return FALSE;
	}
	else
	{	
		for(i = 0;i < pstMatrixResult->ucRow;i++)
		{
			for(j = 0;j < pstMatrixResult->ucCol;j++)
			{
				*(pstMatrixResult->pfDataAdd + i * pstMatrixResult->ucCol + j) = *(pstMatrixA->pfDataAdd + i * pstMatrixResult->ucCol + j)
																		       + *(pstMatrixB->pfDataAdd + i * pstMatrixResult->ucCol + j);
			}				
		}
		return TRUE;
	}
}

				  BOOL SubtractMatrix(IN const Matrix_s *pstMatrixA,
									IN const Matrix_s *pstMatrixB,
									OUT Matrix_s *pstMatrixResult)
				  {
					  int i;
					  int j;
					  if((pstMatrixA->ucRow != pstMatrixB->ucRow)||(pstMatrixA->ucCol != pstMatrixB->ucCol))
					  {
						  printf("相减的两个矩阵的行或列不满足矩阵相减条件！\r\n");
						  return FALSE;
					  }
					  else if((pstMatrixA->ucRow != pstMatrixResult->ucRow)||(pstMatrixA->ucCol != pstMatrixResult->ucCol))
					  {
						  printf("矩阵相减的结果矩阵的行或列不满足矩阵相减条件！\r\n");
						  return FALSE;
					  }
					  else
					  {   
						  for(i = 0;i < pstMatrixResult->ucRow;i++)
						  {
							  for(j = 0;j < pstMatrixResult->ucCol;j++)
							  {
								  *(pstMatrixResult->pfDataAdd + i * pstMatrixResult->ucCol + j) = *(pstMatrixA->pfDataAdd + i * pstMatrixResult->ucCol + j)
																								 - *(pstMatrixB->pfDataAdd + i * pstMatrixResult->ucCol + j);
							  } 			  
						  }
						  return TRUE;
					  }
				  }



