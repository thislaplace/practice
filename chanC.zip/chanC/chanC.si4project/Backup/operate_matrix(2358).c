int OperateMatrix(int iOpCode, Matrix_s *pstMatrixA, Matrix_s *pstMatrixB)
{
	int iRet = EX_FALSE;
	Matrix_s stMatrixC;
	float *pfTmpBuf = NULL;

	memset(&stMatrixC, 0, sizeof(Matrix_s));

	switch (iOpCode)
	{
		case EX_INPUT_MATRIX:
			iRet = Show_matrix(pstMatrixA, pstMatrixB);
			
			if (EX_FALSE == iRet)
			{
				printf("err input matrix info!\n");
				return iRet;
			}
			else
			{
				/* at first, we need input matrix data */
				g_cFlag = EX_MATRIX_INIT;
			}
			break;

		case EX_ADD_MATRIX:/*Addition part.*/
			iRet = AddMatrix(EX_ADD_MATRIX, pstMatrixA, pstMatrixB, &stMatrixC);

			if (EX_TRUE != iRet)/*For checking.*/
			{
				printf("err multiply matrix operation!\n");

				if (EX_MALLOC == iRet)
				{
					;
				}
				else
				{
					free(stMatrixC.pfDataAdd);
				}
				return iRet;
			}

			printf("\r\nA + B =: \r\n");

			iRet = PrintMatrixData(&stMatrixC);
			if (iRet == EX_FALSE)
			{
				printf("err print Matrix result!\r\n");
				free(stMatrixC.pfDataAdd);
				return iRet;
			}

			free(stMatrixC.pfDataAdd);
			break;

		case EX_SUBTRACT_MATRIX:/*Subtract two matrices*/
			iRet = SubtractMatrix(EX_SUBTRACT_MATRIX, pstMatrixA, pstMatrixB, &stMatrixC);

			if (EX_TRUE != iRet)/*For checking.*/
			{
				printf("err subtract matrix operation!\r\n");

				if (EX_MALLOC == iRet)
				{
					;
				}
				else
				{
					free(stMatrixC.pfDataAdd);
				}
				return iRet;
			}

			printf("\r\nA - B =: \r\n");

			iRet = PrintMatrixData(&stMatrixC);
			if (iRet == EX_FALSE)
			{
				printf("err print Matrix result!\r\n");
				free(stMatrixC.pfDataAdd);
				return iRet;
			}

			free(stMatrixC.pfDataAdd);	
			break;

		case EX_MULTIPLY_MATRIX:/*multiplication part.*/
			iRet = MultiplyMatrix(EX_MULTIPLY_MATRIX, pstMatrixA, pstMatrixB, &stMatrixC);

			if (EX_TRUE != iRet)/*For checking.*/
			{
				printf("\r\nerr multiply matrix operation!\r\n");

				if (EX_MALLOC == iRet)
				{
					;
				}
				else
				{
					free(stMatrixC.pfDataAdd);
				}
				return iRet;
			}

			printf("\r\nA * B =: \r\n");

			iRet = PrintMatrixData(&stMatrixC);
			if (EX_TRUE != iRet)
			{
				printf("err print Matrix result!\r\n");
				free(stMatrixC.pfDataAdd);
				return iRet;
			}

			free(stMatrixC.pfDataAdd);	
			break;

		case EX_INVERSE_MATRIX:/*inverse.*/
			if (EX_MATRIX_UNINIT == g_cFlag)/*For checking the input.*/
			{
				printf("please choose 1 operation at first.\r\n");
				return EX_FALSE;
			}

			pfTmpBuf = (float *)malloc(pstMatrixA->ucRow * pstMatrixA->ucCol * sizeof(float));
	
			if (pfTmpBuf == NULL)/*For checking.*/
			{
				printf("err malloc memory.\r\n");
				return EX_MALLOC;
			}
			else
			{
				memset(pfTmpBuf, 0, (pstMatrixA->ucRow * pstMatrixA->ucCol * sizeof(float)));
				memcpy(pfTmpBuf, pstMatrixA->pfDataAdd, (pstMatrixA->ucRow * pstMatrixA->ucCol * sizeof(float)));
			}

			stMatrixC.ucCol = pstMatrixA->ucCol;
			stMatrixC.ucRow = pstMatrixA->ucRow;
			stMatrixC.pfDataAdd = pfTmpBuf;
			

			iRet = InverseMatrix(stMatrixC.pfDataAdd, stMatrixC.ucRow);

			if (EX_TRUE != iRet)/*For checking.*/
			{
				printf("\r\nerr inverse matrix operation!\r\n");

				if (EX_MALLOC == iRet)
				{
					;
				}
				else
				{
					free(stMatrixC.pfDataAdd);
				}
				return iRet;
			}

			printf("\r\nInverse of A =: \r\n");

			iRet = PrintInverseMatrixData(&stMatrixC);
			if (EX_TRUE != iRet)/*For checking.*/
			{
				printf("err print Matrix result!\r\n");
				free(stMatrixC.pfDataAdd);
				return iRet;
			}

			free(stMatrixC.pfDataAdd);
			break;

		case EX_QUIT_MATRIX:/*users chose to end this program.*/
			printf("will quit matrix menu!\r\n");

			break;

		default:/*For checking.*/
			printf("err operate code!\r\n");
			return EX_FALSE;
	}

	return EX_TRUE;
}

int CheckMatrix(int iOpCode, Matrix_s *pstMatrixA, Matrix_s *pstMatrixB)
{
	if ((pstMatrixA == NULL) || (pstMatrixB == NULL))
	{
		printf("matrix para is null.\r\n");
		return EX_FALSE;
	}
	
	if (EX_MATRIX_UNINIT == g_cFlag)
	{
		printf("please choose 1 operation at first.\r\n");
		return EX_FALSE;
	}

	switch (iOpCode)
	{
		case EX_ADD_MATRIX:
        case EX_SUBTRACT_MATRIX:
			if ((pstMatrixA->ucCol == pstMatrixB->ucCol)
				&& (pstMatrixA->ucRow == pstMatrixB->ucRow))
			{
				;
			}
			else
			{
				/* ADD / Subtract operation */
				printf("\r\nAdd/Subtract operation is invalid!\r\n");
				return EX_FALSE;
			}
			break;
		
		case EX_INVERSE_MATRIX:
			if ((2 == pstMatrixA->ucRow)
				&& (2 == pstMatrixA->ucCol))
			{
				;
			}
			else
			{
				/* Inverse operation */
				printf("\r\nMultiply/Inverse operation is invalid!\r\n");
				return EX_FALSE;
			}
			break;

		case EX_MULTIPLY_MATRIX:
			if ((pstMatrixA->ucRow == pstMatrixB->ucCol)
				&& (pstMatrixA->ucCol == pstMatrixB->ucRow))
			{
				;
			}
			else
			{
				/* Multiply operation */
				printf("\r\nMultiply operation is invalid!\r\n");
				return EX_FALSE;
			}
			break;

		default:
			printf("err operate code!\r\n");
			return EX_FALSE;
	}

	return EX_TRUE;
}

int AddMatrix(int iOpCode, Matrix_s *pstMatrixA, Matrix_s *pstMatrixB, Matrix_s *pstMatrixC)
{
	int iRet = EX_FALSE;
	unsigned char ucRow;
	unsigned char ucCol;
	unsigned char i, j;
	float fTmpData = 0.0;

	if ((pstMatrixA == NULL) || (pstMatrixB == NULL))
	{
		printf("matrix para is null.\r\n");
		return EX_FALSE;
	}

	iRet = CheckMatrix(iOpCode, pstMatrixA, pstMatrixB);
	if (EX_FALSE == iRet)
	{
		return iRet;
	}
	else
	{
		ucRow = pstMatrixA->ucRow;
		ucCol = pstMatrixA->ucCol;
	}
	
	/* create result matrix C */
	iRet = CreateResultMatrix(ucRow, ucCol, pstMatrixC);
	if (iRet != EX_TRUE)
	{
		return iRet;
	}

	for (i = 0; i < ucRow; i++)
	{
		for (j = 0; j < ucCol; j++)
		{
			fTmpData = (*(pstMatrixA->pfDataAdd + i * ucCol + j) + *(pstMatrixB->pfDataAdd + i * ucCol + j));	
			
			*(pstMatrixC->pfDataAdd + i * ucCol + j) = fTmpData;
		}
	}

	return EX_TRUE;
}

int SubtractMatrix(int iOpCode, Matrix_s *pstMatrixA, Matrix_s *pstMatrixB, Matrix_s *pstMatrixC)
{
	int iRet = EX_FALSE;
	unsigned char ucRow;
	unsigned char ucCol;
	unsigned char i, j;
	float fTmpData = 0.0;

	if ((pstMatrixA == NULL) || (pstMatrixB == NULL))
	{
		printf("matrix para is null.\r\n");
		return EX_FALSE;
	}

	iRet = CheckMatrix(iOpCode, pstMatrixA, pstMatrixB);
	if (EX_FALSE == iRet)
	{
		return iRet;
	}
	else
	{
		ucRow = pstMatrixA->ucRow;
		ucCol = pstMatrixA->ucCol;
	}
	
	/* create result matrix C */
	iRet = CreateResultMatrix(ucRow, ucCol, pstMatrixC);
	if (iRet != EX_TRUE)
	{
		return iRet;
	}

	for (i = 0; i < ucRow; i++)
	{
		for (j = 0; j < ucCol; j++)
		{
			fTmpData = (*(pstMatrixA->pfDataAdd + i * ucCol + j) - *(pstMatrixB->pfDataAdd + i * ucCol + j));	
			
			*(pstMatrixC->pfDataAdd + i * ucCol + j) = fTmpData;
		}
	}

	return EX_TRUE;
}

int MultiplyMatrix(int iOpCode, Matrix_s *pstMatrixA, Matrix_s *pstMatrixB, Matrix_s *pstMatrixC)
{
	int iRet = EX_FALSE;
	unsigned char ucRow;
	unsigned char ucCol;
	unsigned char i, j, k;
	float fTmpData = 0.0;

	if ((pstMatrixA == NULL) || (pstMatrixB == NULL))
	{
		printf("matrix para is null.\r\n");
		return EX_FALSE;
	}

	iRet = CheckMatrix(iOpCode, pstMatrixA, pstMatrixB);
	if (EX_FALSE == iRet)
	{
		return iRet;
	}
	else
	{
		ucRow = pstMatrixA->ucRow;
		ucCol = pstMatrixB->ucCol;
	}
	
	/* create result matrix C */
	iRet = CreateResultMatrix(ucRow, ucCol, pstMatrixC);
	if (iRet != EX_TRUE)
	{
		return iRet;
	}

	for (i = 0; i < ucRow; i++)
	{
		for (j = 0; j < ucCol; j++)
		{
			for (k = 0; k < pstMatrixA->ucCol; k++)
			{
				fTmpData += (float)(*(pstMatrixA->pfDataAdd + i * ucCol + k) * *(pstMatrixB->pfDataAdd + j + k * ucCol));	
			}

			*(pstMatrixC->pfDataAdd + i * ucCol + j) = fTmpData;
			fTmpData = 0;
		}
	}

	return EX_TRUE;
}

int CreateResultMatrix(unsigned char ucRow, unsigned char ucCol, void *pvData)
{
	Matrix_s *pstTmpData = NULL;
	int iRet = EX_FALSE;
	if (pvData == NULL)
	{
		printf("para is null.\r\n");
		return EX_FALSE;
	}
	else
	{
		pstTmpData = (Matrix_s *)pvData;
	}

	/* create result matrix C */
	memset(pstTmpData, 0, sizeof(Matrix_s));

	pstTmpData->ucRow = ucRow;
	pstTmpData->ucCol = ucCol;

	iRet = CreateMatrixMem(pstTmpData);
	if (iRet != EX_TRUE)
	{
		printf("err create result Matrix C!\r\n");
		return iRet;
	}

	return EX_TRUE;
}

int InverseMatrix(float a[], int n)
{ 
	int *is,*js;
	int i,j,k,l,u,v;
    float d, p;

    is = (int *)malloc(n * sizeof(int));
    js = (int *)malloc(n * sizeof(int));
    for (k = 0; k <= n-1; k++)
	{ 
		d = 0.0;
		for (i = k; i <= n-1; i++)
		{	for (j = k; j <= n-1; j++)
			{ 
				l = i * n + j; 
				p = (float)fabs(a[l]);
				if (p > d)
				{ 
					d = p; 
					is[k] = i; 
					js[k] = j;
				}
			}
		}

		if (d + 1.0 == 1.0)
		{ 
			free(is); 
			free(js); 
			printf("err not inverse!\r\n");
			return EX_FALSE;
		}

		if (is[k] != k)
		{	for (j=0; j<=n-1; j++)
			{ 
				u = k * n + j; 
				v = is[k] * n +j;
				p = a[u]; 
				a[u] = a[v]; 
				a[v] = p;
			}
		}

		if (js[k] != k)
		{	
			for (i=0; i<=n-1; i++)
			{ 
				u = i*n+k; 
				v = i*n+js[k];
				p = a[u]; 
				a[u] = a[v]; 
				a[v] = p;
			}
		}

		l = k * n + k;
		a[l] = (float)(1.0 / a[l]);
		for (j = 0; j <= n-1; j++)
		{	
			if (j != k)
			{ 
				u = k * n + j; 
				a[u] = a[u] * a[l];
			}
		}

		for (i = 0; i <= n-1; i++)
		{	
			if (i != k)
			{	
				for (j = 0; j <= n-1; j++)
				{	
					if (j != k)
					{ 
						u = i * n + j;
						a[u] = a[u] - a[i * n + k] * a[k * n + j];
					}
				}
				for (i = 0; i <= n-1; i++)
				{	
					if (i != k)
					{ 
						u = i * n + k; 
						a[u] = -a[u] * a[l];
					}
				}
			}
		}
	}
    for (k = n-1; k >= 0; k--)
	{ 
		if (js[k] != k)
		for (j = 0; j <= n-1; j++)
		{ 
			u = k * n + j; 
			v = js[k] * n + j;
			p = a[u]; 
			a[u] = a[v]; 
			a[v] = p;
		}
		if (is[k] != k)
		for (i = 0; i <= n-1; i++)
		{ 
			u = i * n + k; 
			v = i * n + is[k];
			p = a[u]; 
			a[u] = a[v]; 
			a[v] = p;
		}
	}

	free(is); 
	free(js);
	return EX_TRUE;
}
