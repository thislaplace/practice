#include <stdio.h>
#include"./matrix.h"

#define TEST_ROW (3)
#define TEST_COL (6)

int main(int argc, char *argv[])
{
	float TEST_data[TEST_ROW*TEST_COL]={300.0,100,150,400,150,100,
						 				300,500,200,350,200,100,
 										100.0,100.1,100.2,100.3,100.4,100.5};
	Matrix_s *pstMatrix_data;
	pstMatrix_data = (Matrix_s*) malloc(sizeof(Matrix_s));
	
	if(FALSE != CreatMatrix(TEST_ROW, TEST_COL, TEST_data, pstMatrix_data))
	{
		DisplayMatrix(pstMatrix_data);
	}

	return 0;
}

