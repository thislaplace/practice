#include <stdio.h>
#include <stdlib.h>
#include"matrix.h"

void DisplayMatrix(IN const Matrix_s *pstMatrix)
{
	int i;
	int j;
	for(i = 0;i < pstMatrix->ucCol;i++)
	{
		for(j = 0;j < pstMatrix->ucRow;j++)
		{
			printf(" \t",*(pstMatrix->pfDataAdd + i * pstMatrix->ucCol + j));
		}
		printf("\r\n");
	}
}

unsigned int GetMatrixRow(IN const Matrix_s *pstMatrix)
{
	return pstMatrix->ucRow;
}

unsigned int GetMatrixCol(IN const Matrix_s *pstMatrix)
{
	return pstMatrix->ucCol;
}

BOOL CreatMatrix(IN unsigned char ucRow, 
				IN unsigned char ucCol, 
		  		IN const float *pvData, 
			 	OUT Matrix_s *pstMatrix)
{
	int i;
	int j;
	if (pvData == NULL)
	{
		printf("Creat matrix fault; para is null.\r\n");
		return FALSE;
	}
	else
	{
	
		Matrix_s *pstTmpData = NULL;		
		//memset(pstTmpData, 0, sizeof(Matrix_s));
		pstTmpData->ucRow = ucRow;
		pstTmpData->ucCol = ucCol;
		//pstTmpData->pfDataAdd = (float*)malloc(sizeof(float)*pstTmpData->ucRow*pstTmpData->ucCol);
		/*	for(i = 0;i < pstTmpData->ucCol;i++)
		{
			for(j = 0;j < pstTmpData->ucRow;j++)
			{
				*(pstTmpData->pfDataAdd + i * pstTmpData->ucCol + j) = *(pvData+ i * pstTmpData->ucCol + j);
			}
		}
		*/
		return TRUE;
	}
}






BOOL AddMatrix( const Matrix_s *pstMatrixA,
			    const Matrix_s *pstMatrixB,
			    Matrix_s *pstMatrixC)
{
	if((pstMatrixA->ucRow != pstMatrixB->ucRow)||(pstMatrixA->ucCol != pstMatrixB->ucCol))
		return FALSE;

	

}



