#include <stdio.h>
#include"./matrix.h"

#define TEST_ROW 6
#define TEST_COL 3

int main(int argc, char *argv[])
{
	float TEST_data[18]={300.0,100,150,400,150,100,
						 300,500,200,350,200,100,
						 -100.0,-100.0,-100.0,-100.0,-100.0,-100.0};
	Matrix_s *pstMatrix_data;


	if(FALSE != CreatMatrix(TEST_ROW, TEST_COL, TEST_data, pstMatrix_data))
	{
		DisplayMatrix(pstMatrix_data);
	}
	
	return 0;
}

